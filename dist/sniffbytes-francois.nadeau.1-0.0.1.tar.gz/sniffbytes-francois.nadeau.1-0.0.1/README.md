# Sniffbytes

### Bytes manipulation functions to repair datas and find dialect
### where CSV.Sniffer() can't

#### Requires Python>3.5

#### Installing requirements

``` python3 -m pip install -r requirements.txt ```

- For each function's details and help documentation, please
  read function's scripts.

